@echo off
rem Fallback launcher: may flash a console window for a moment.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0LinkPanel.ps1"
exit
