﻿<#
    链接浮窗 (LinkPanel)
    ------------------------------------------------------------
    纯 PowerShell + WinForms 实现的置顶浮窗：链接清单写在同目录的 links.txt，
    保存后约 1.5 秒自动刷新，点击条目用默认程序打开。不需要安装任何依赖。

    启动方式：
        双击  启动面板.vbs          （无黑色控制台窗口，推荐）
        或    右键 LinkPanel.ps1 -> 使用 PowerShell 运行

    参数：
        -ConfigPath <路径>   指定另一个链接清单文件
        -Test                自检模式：解析配置 + 构建界面 + 测试热键，然后退出
        -Capture <图片路径>  自检用：把浮窗渲染成 PNG 后退出

    本地路径的打开方式：
        OpenLocalPathWith = 'system'  -> 用系统默认（文件夹=资源管理器）
        OpenLocalPathWith = 'vscode'  -> 一律用 VS Code 打开
        单条链接可强制指定：在路径前加 code: ，例如
            sglang本地仓 = code:C:\Users\huangxiaojun\Desktop\hxj\SGLANG\sglang
#>
[CmdletBinding()]
param(
    [string]$ConfigPath = '',
    [switch]$Test,
    [string]$Capture = ''
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ================================================================ 路径与常量
$script:AppDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
if ([string]::IsNullOrWhiteSpace($ConfigPath)) { $ConfigPath = Join-Path $script:AppDir 'links.txt' }
$script:ConfigPath = $ConfigPath
$script:StatePath  = Join-Path $script:AppDir 'panel.state'
$script:HotKeyText = 'Ctrl+Alt+Q'

# ---- 本地路径（文件夹/文件）默认用哪个程序打开 ----
#   'system' = 系统默认，文件夹会开资源管理器（默认值）
#   'vscode' = 一律用 VS Code 打开
# 想只对某一条用 VS Code，不用动这里，直接在 links.txt 里写  code:路径  即可
$script:OpenLocalPathWith = 'system'

$script:TestMode   = [bool]$Test
$script:LastWrite  = [DateTime]::MinValue
$script:Items      = @()
$script:Resizing   = $false

# ================================================================ 配色
$script:C = @{
    Bg     = [System.Drawing.Color]::FromArgb(30, 31, 34)
    Card   = [System.Drawing.Color]::FromArgb(43, 45, 48)
    CardHi = [System.Drawing.Color]::FromArgb(58, 61, 66)
    Text   = [System.Drawing.Color]::FromArgb(232, 232, 232)
    Dim    = [System.Drawing.Color]::FromArgb(138, 143, 152)
    Accent = [System.Drawing.Color]::FromArgb(76, 154, 255)
    Sep    = [System.Drawing.Color]::FromArgb(58, 61, 66)
}

function New-FontSafe {
    param(
        [string]$Family,
        [float]$Size,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )
    try { return (New-Object System.Drawing.Font($Family, $Size, $Style)) }
    catch { return (New-Object System.Drawing.Font('Segoe UI', $Size, $Style)) }
}

# ================================================================ 读取链接清单
function Get-LinkItems {
    param([string]$Path)

    $list = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path -LiteralPath $Path)) { return $list }

    $lines = @(Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction SilentlyContinue)
    foreach ($raw in $lines) {
        $line = $raw.Trim()
        if ($line -eq '') { continue }
        if ($line.StartsWith('//')) { continue }

        # 分组标题
        if ($line -match '^#+\s*(.+?)\s*$') {
            $list.Add([pscustomobject]@{ Kind = 'header'; Name = $matches[1]; Url = '' })
            continue
        }
        # 分隔线
        if ($line -match '^[-=]{3,}$') {
            $list.Add([pscustomobject]@{ Kind = 'sep'; Name = ''; Url = '' })
            continue
        }

        $name = ''
        $url  = ''
        if ($line -match '^[a-zA-Z][a-zA-Z0-9+.\-]*:' -or $line.StartsWith('\\')) {
            # 整行就是一个地址 / 本地路径
            $url = $line
        }
        else {
            $m = [regex]::Match($line, '^(?<n>.+?)\s*[=|]\s*(?<u>\S.*)$')
            if ($m.Success) {
                $name = $m.Groups['n'].Value.Trim()
                $url  = $m.Groups['u'].Value.Trim()
            }
            else {
                $url = $line
            }
        }
        if ([string]::IsNullOrWhiteSpace($url)) { continue }
        if ([string]::IsNullOrWhiteSpace($name)) { $name = $url }

        $list.Add([pscustomobject]@{ Kind = 'link'; Name = $name; Url = (Resolve-LinkUrl $url) })
    }
    return $list
}

# 补全协议头、展开环境变量，便于直接写 github.com 或 %USERPROFILE%\Downloads
function Resolve-LinkUrl {
    param([string]$Url)
    $u = [System.Environment]::ExpandEnvironmentVariables($Url.Trim())

    # 显式要求用 VS Code 打开：code:<路径>
    if ($u -match '^(?i)code:\s*(.+)$') { return 'code://' + $matches[1].Trim() }

    if ($u -match '^[a-zA-Z][a-zA-Z0-9+.\-]*:') {
        # 本地盘符路径：按全局设置决定要不要改用 VS Code
        if ($script:OpenLocalPathWith -eq 'vscode' -and $u -match '^[a-zA-Z]:[\\/]') {
            return 'code://' + $u
        }
        return $u
    }
    if ($u.StartsWith('\\')) { return $u }
    return 'https://' + $u
}

# ================================================================ 打开链接
function Get-CodeExe {
    foreach ($c in @(
            (Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'),
            (Join-Path $env:ProgramFiles 'Microsoft VS Code\Code.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'Microsoft VS Code\Code.exe'))) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    $cmd = Get-Command 'code.cmd' -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Open-LinkUrl {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) { return }
    try {
        if ($Url -like 'code://*') {
            $path = $Url.Substring(7)
            if (-not (Test-Path -LiteralPath $path)) { throw "路径不存在：$path" }
            $code = Get-CodeExe
            if (-not $code) { throw '没有找到 VS Code（Code.exe / code.cmd）' }
            Start-Process -FilePath $code -ArgumentList ('"' + $path + '"') | Out-Null
            return
        }
        Start-Process $Url | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "无法打开：$Url`r`n`r`n$($_.Exception.Message)",
            '链接浮窗', 'OK', 'Warning') | Out-Null
    }
}

function Edit-LinkFile {
    if (Test-Path -LiteralPath $script:ConfigPath) {
        Start-Process 'notepad.exe' -ArgumentList ('"' + $script:ConfigPath + '"') | Out-Null
    }
    else {
        Start-Process 'notepad.exe' | Out-Null
    }
}

# ================================================================ 界面
function Build-Ui {
    $C = $script:C

    $fontUi   = New-FontSafe 'Microsoft YaHei UI' 9.5 ([System.Drawing.FontStyle]::Regular)
    $fontBold = New-FontSafe 'Microsoft YaHei UI' 9.5 ([System.Drawing.FontStyle]::Bold)
    $fontIcon = New-FontSafe 'Segoe MDL2 Assets' 9.5 ([System.Drawing.FontStyle]::Regular)

    # -------- 窗口 --------
    $w = 300; $h = 480
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $x = $wa.Right - $w - 24
    $y = $wa.Top + 60

    if (Test-Path -LiteralPath $script:StatePath) {
        try {
            $p = @((Get-Content -LiteralPath $script:StatePath -Raw).Split(',')) | ForEach-Object { [int]$_.Trim() }
            if ($p.Count -eq 4) {
                $x = $p[0]; $y = $p[1]; $w = [Math]::Max(220, $p[2]); $h = [Math]::Max(180, $p[3])
            }
        }
        catch { }
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text            = '链接浮窗'
    $form.FormBorderStyle = 'None'
    $form.StartPosition   = 'Manual'
    $form.ShowInTaskbar   = $true
    $form.TopMost         = $true
    $form.KeyPreview      = $true
    $form.MinimumSize     = New-Object System.Drawing.Size(220, 180)
    $form.BackColor       = $C.Bg
    $form.Size            = New-Object System.Drawing.Size($w, $h)
    $form.Location        = New-Object System.Drawing.Point($x, $y)
    $form.Icon            = [System.Drawing.SystemIcons]::Application

    $script:Form = $form

    # -------- 布局容器（标题栏 + 内容区）--------
    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.ColumnCount = 1
    $layout.RowCount = 2
    $layout.BackColor = $C.Bg
    $layout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 34))) | Out-Null
    $layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
    $form.Controls.Add($layout)

    # -------- 标题栏 --------
    $title = New-Object System.Windows.Forms.Panel
    $title.Dock = 'Fill'
    $title.BackColor = $C.Bg
    $layout.Controls.Add($title, 0, 0)

    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text = '链接浮窗'
    $lblTitle.Font = $fontBold
    $lblTitle.ForeColor = $C.Text
    $lblTitle.AutoSize = $true
    $lblTitle.Location = New-Object System.Drawing.Point(10, 9)
    $lblTitle.Cursor = [System.Windows.Forms.Cursors]::SizeAll
    $title.Controls.Add($lblTitle)

    $tip = New-Object System.Windows.Forms.ToolTip
    $tip.SetToolTip($lblTitle, '按住拖动窗口')
    $script:Tip = $tip

    function New-TitleButton {
        param([string]$Glyph, [string]$Hint, [float]$FontSize = 9.5)
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $Glyph
        $b.Font = New-FontSafe 'Segoe MDL2 Assets' $FontSize ([System.Drawing.FontStyle]::Regular)
        $b.Size = New-Object System.Drawing.Size(34, 34)
        $b.FlatStyle = 'Flat'
        $b.FlatAppearance.BorderSize = 0
        $b.FlatAppearance.MouseOverBackColor = $C.CardHi
        $b.BackColor = $C.Bg
        $b.ForeColor = $C.Dim
        $b.Dock = 'Right'
        $b.TabStop = $false
        $b.Cursor = [System.Windows.Forms.Cursors]::Hand
        $tip.SetToolTip($b, $Hint)
        $title.Controls.Add($b)
        return $b
    }

    # 字符来自 Segoe MDL2 Assets：E8BB=关闭  E713=设置  E72C=刷新  E718=置顶
    $btnClose  = New-TitleButton ([char]0xE8BB) '隐藏到托盘（托盘菜单可退出）'
    $btnEdit   = New-TitleButton ([char]0xE713) '编辑链接清单 links.txt'
    $btnReload = New-TitleButton ([char]0xE72C) '立即重新加载'
    $btnPin    = New-TitleButton ([char]0xE718) '取消置顶 / 恢复置顶'
    $script:BtnPin = $btnPin

    # -------- 内容区 --------
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.Dock = 'Fill'
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoScroll = $true
    $flow.BackColor = $C.Bg
    $flow.Padding = New-Object System.Windows.Forms.Padding(8, 2, 8, 8)
    $layout.Controls.Add($flow, 0, 1)
    $script:Flow = $flow

    # -------- 右下角缩放把手 --------
    $grip = New-Object System.Windows.Forms.Panel
    $grip.Size = New-Object System.Drawing.Size(16, 16)
    $grip.BackColor = $C.Bg
    $grip.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right)
    $grip.Cursor = [System.Windows.Forms.Cursors]::SizeNWSE
    $grip.Location = New-Object System.Drawing.Point(($form.ClientSize.Width - 16), ($form.ClientSize.Height - 16))
    $form.Controls.Add($grip)
    $grip.BringToFront()

    # -------- 拖动移动窗口 --------
    $script:Dragging = $false
    $script:DragStart = New-Object System.Drawing.Point(0, 0)
    $script:FormStart = New-Object System.Drawing.Point(0, 0)

    $dragDown = {
        param($sender, $e)
        if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) {
            $script:Dragging = $true
            $script:DragStart = [System.Windows.Forms.Cursor]::Position
            $script:FormStart = $script:Form.Location
        }
    }
    $dragMove = {
        param($sender, $e)
        if ($script:Dragging) {
            $now = [System.Windows.Forms.Cursor]::Position
            $script:Form.Location = New-Object System.Drawing.Point(
                ($script:FormStart.X + ($now.X - $script:DragStart.X)),
                ($script:FormStart.Y + ($now.Y - $script:DragStart.Y)))
        }
    }
    $dragUp = { param($sender, $e) $script:Dragging = $false }

    $title.Add_MouseDown($dragDown);  $lblTitle.Add_MouseDown($dragDown)
    $title.Add_MouseMove($dragMove);  $lblTitle.Add_MouseMove($dragMove)
    $title.Add_MouseUp($dragUp);      $lblTitle.Add_MouseUp($dragUp)

    # -------- 缩放窗口 --------
    $grip.Add_MouseDown({
        $script:Resizing = $true
        $script:rStart = [System.Windows.Forms.Cursor]::Position
        $script:rSize = $script:Form.Size
    })
    $grip.Add_MouseMove({
        if ($script:Resizing) {
            $p = [System.Windows.Forms.Cursor]::Position
            $script:Form.Size = New-Object System.Drawing.Size(
                [Math]::Max(220, $script:rSize.Width + ($p.X - $script:rStart.X)),
                [Math]::Max(180, $script:rSize.Height + ($p.Y - $script:rStart.Y)))
        }
    })
    $grip.Add_MouseUp({ $script:Resizing = $false })

    # -------- 标题栏按钮行为 --------
    $btnClose.Add_Click({
        $script:Form.Hide()
        if (-not $script:HintShown) {
            $script:HintShown = $true
            $script:Tray.ShowBalloonTip(2000, '链接浮窗', "已隐藏到托盘。按 $script:HotKeyText 或双击托盘图标可再次打开。", 'Info')
        }
    })
    $btnEdit.Add_Click({ Edit-LinkFile })
    $btnReload.Add_Click({ Update-Content })
    $btnPin.Add_Click({
        $script:Form.TopMost = -not $script:Form.TopMost
        if ($script:Form.TopMost) { $script:BtnPin.ForeColor = $script:C.Accent }
        else                      { $script:BtnPin.ForeColor = $script:C.Dim }
    })
    $btnPin.ForeColor = $C.Accent

    $form.Add_KeyDown({
        if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Escape) { $script:Form.Hide() }
        elseif ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::R) { Update-Content }
    })

    # 窗口尺寸变化时同步刷新条目宽度
    $flow.Add_ClientSizeChanged({ Set-ItemWidths })

    # 记住窗口位置和大小
    $form.Add_FormClosing({
        try {
            $s = '{0},{1},{2},{3}' -f $script:Form.Location.X, $script:Form.Location.Y, $script:Form.Width, $script:Form.Height
            Set-Content -LiteralPath $script:StatePath -Value $s -Encoding ASCII
        }
        catch { }
    })

    return $form
}

# ================================================================ 渲染链接条目
function Set-ItemWidths {
    if (-not $script:Flow) { return }
    $w = $script:Flow.ClientSize.Width - $script:Flow.Padding.Horizontal - 20
    if ($w -lt 80) { $w = 80 }
    foreach ($c in $script:Flow.Controls) {
        if ($c -is [System.Windows.Forms.Button]) { $c.Width = $w }
    }
}

function Update-Content {
    if (-not $script:Flow) { return }

    $C = $script:C
    $script:Flow.SuspendLayout()

    $old = @($script:Flow.Controls)
    $script:Flow.Controls.Clear()
    foreach ($c in $old) { $c.Dispose() }

    $script:Items = @(Get-LinkItems -Path $script:ConfigPath)

    if ($script:Items.Count -eq 0) {
        $hint = New-Object System.Windows.Forms.Label
        $hint.Text = "还没有链接。`r`n点标题栏的齿轮按钮编辑 links.txt，`r`n每行写「名称 = 网址」即可。"
        $hint.Font = New-FontSafe 'Microsoft YaHei UI' 9 ([System.Drawing.FontStyle]::Regular)
        $hint.ForeColor = $C.Dim
        $hint.AutoSize = $true
        $hint.MaximumSize = New-Object System.Drawing.Size(240, 0)
        $hint.Margin = New-Object System.Windows.Forms.Padding(2, 6, 0, 0)
        $script:Flow.Controls.Add($hint)
    }

    foreach ($item in $script:Items) {
        switch ($item.Kind) {
            'header' {
                $lbl = New-Object System.Windows.Forms.Label
                $lbl.Text = $item.Name
                $lbl.Font = New-FontSafe 'Microsoft YaHei UI' 8.5 ([System.Drawing.FontStyle]::Bold)
                $lbl.ForeColor = $C.Accent
                $lbl.AutoSize = $true
                $lbl.Margin = New-Object System.Windows.Forms.Padding(4, 8, 0, 3)
                $script:Flow.Controls.Add($lbl)
            }
            'sep' {
                $line = New-Object System.Windows.Forms.Panel
                $line.Height = 1
                $line.Width = 200
                $line.BackColor = $C.Sep
                $line.Margin = New-Object System.Windows.Forms.Padding(4, 8, 4, 8)
                $script:Flow.Controls.Add($line)
            }
            'link' {
                $btn = New-Object System.Windows.Forms.Button
                $btn.Text = '  ' + $item.Name
                $btn.TextAlign = 'MiddleLeft'
                $btn.Font = New-FontSafe 'Microsoft YaHei UI' 9.5 ([System.Drawing.FontStyle]::Regular)
                $btn.FlatStyle = 'Flat'
                $btn.FlatAppearance.BorderSize = 0
                $btn.FlatAppearance.MouseOverBackColor = $C.CardHi
                $btn.FlatAppearance.MouseDownBackColor = $C.CardHi
                $btn.BackColor = $C.Card
                $btn.ForeColor = $C.Text
                $btn.Height = 28
                $btn.Width = 200
                $btn.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 3)
                $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
                $btn.TabStop = $false
                $btn.Tag = $item.Url
                $btn.Add_Click({ Open-LinkUrl $this.Tag })

                $ctx = New-Object System.Windows.Forms.ContextMenuStrip
                $miCopy = $ctx.Items.Add('复制链接')
                $miCopy.Add_Click({
                    # $this 是菜单项，$this.Owner 是它所属的右键菜单
                    $src = $this.Owner.SourceControl
                    if ($src) {
                        try { [System.Windows.Forms.Clipboard]::SetText([string]$src.Tag) } catch { }
                    }
                })
                $btn.ContextMenuStrip = $ctx

                $script:Tip.SetToolTip($btn, $item.Url)
                $script:Flow.Controls.Add($btn)
            }
        }
    }

    $script:Flow.ResumeLayout()
    Set-ItemWidths

    if (Test-Path -LiteralPath $script:ConfigPath) {
        try { $script:LastWrite = (Get-Item -LiteralPath $script:ConfigPath).LastWriteTimeUtc } catch { }
    }
}

# ================================================================ 托盘图标
function Build-Tray {
    $tray = New-Object System.Windows.Forms.NotifyIcon
    $tray.Icon = [System.Drawing.SystemIcons]::Application
    $tray.Text = '链接浮窗'
    $tray.Visible = $true

    $menu = New-Object System.Windows.Forms.ContextMenuStrip
    $miToggle = $menu.Items.Add("显示 / 隐藏  ($script:HotKeyText)")
    $miReload = $menu.Items.Add('重新加载链接')
    $miEdit   = $menu.Items.Add('编辑 links.txt')
    $miDir    = $menu.Items.Add('打开所在文件夹')
    $menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
    $miExit   = $menu.Items.Add('退出')

    $miToggle.Add_Click({ Toggle-Panel })
    $miReload.Add_Click({ Update-Content })
    $miEdit.Add_Click({ Edit-LinkFile })
    $miDir.Add_Click({ Start-Process 'explorer.exe' -ArgumentList ('"' + $script:AppDir + '"') | Out-Null })
    $miExit.Add_Click({ Stop-App })

    $tray.ContextMenuStrip = $menu
    $tray.Add_MouseDoubleClick({ Toggle-Panel })

    $script:Tray = $tray
    return $tray
}

function Toggle-Panel {
    if (-not $script:Form) { return }
    if ($script:Form.Visible) {
        $script:Form.Hide()
    }
    else {
        $script:Form.Show()
        $script:Form.Activate()
        $script:Form.BringToFront()
    }
}

function Stop-App {
    try { $script:Timer.Stop() } catch { }
    try { Unregister-HotKey } catch { }
    try { if ($script:Tray) { $script:Tray.Visible = $false; $script:Tray.Dispose() } } catch { }
    try { $script:Form.Close() } catch { }
}

# ================================================================ 全局热键
$script:HotKeySource = @'
using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

public class LinkPanelHotKey : NativeWindow
{
    [DllImport("user32.dll")] private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    private const int WM_HOTKEY = 0x0312;
    private const int Id = 0x4C50;
    private bool _registered = false;

    public event EventHandler Pressed;

    public bool Register(uint modifiers, uint key)
    {
        CreateHandle(new CreateParams());
        _registered = RegisterHotKey(this.Handle, Id, modifiers, key);
        return _registered;
    }

    public void Unregister()
    {
        if (_registered && this.Handle != IntPtr.Zero)
        {
            UnregisterHotKey(this.Handle, Id);
            _registered = false;
        }
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_HOTKEY && (int)m.WParam == Id)
        {
            EventHandler h = Pressed;
            if (h != null) { h(this, EventArgs.Empty); }
        }
        base.WndProc(ref m);
    }
}
'@

function Register-HotKey {
    # Ctrl + Alt + Q
    $MOD_ALT = 0x0001; $MOD_CONTROL = 0x0002
    $VK_Q = 0x51
    try {
        if (-not ('LinkPanelHotKey' -as [type])) {
            Add-Type -TypeDefinition $script:HotKeySource -ReferencedAssemblies 'System.Windows.Forms', 'System.Drawing'
        }
        $obj = New-Object LinkPanelHotKey
        $script:HotKey = $obj
        $script:HotKey.Add_Pressed({ Toggle-Panel })
        $ok = $obj.Register([uint32]($MOD_CONTROL -bor $MOD_ALT), [uint32]$VK_Q)
        return $ok
    }
    catch {
        Write-Verbose "热键注册失败：$($_.Exception.Message)"
        return $false
    }
}

function Unregister-HotKey {
    if ($script:HotKey) { $script:HotKey.Unregister() }
}

# ================================================================ 启动
function Start-App {
    # 单实例：已经在运行就不再开一个
    $created = $false
    $script:Mutex = New-Object System.Threading.Mutex($true, 'Local\CodexLinkPanel_SingleInstance', [ref]$created)
    if (-not $created) {
        if ($script:Mutex) { $script:Mutex.Dispose() }
        return
    }

    $form = Build-Ui
    Update-Content
    Build-Tray | Out-Null
    Register-HotKey | Out-Null

    # 文件变化自动刷新
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 1500
    $timer.Add_Tick({
        try {
            if (Test-Path -LiteralPath $script:ConfigPath) {
                $t = (Get-Item -LiteralPath $script:ConfigPath).LastWriteTimeUtc
                if ($t -ne $script:LastWrite) { Update-Content }
            }
        }
        catch { }
    })
    $timer.Start()
    $script:Timer = $timer

    try {
        [System.Windows.Forms.Application]::Run($form)
    }
    finally {
        Stop-App
        if ($script:Mutex) { try { $script:Mutex.ReleaseMutex() } catch { }; $script:Mutex.Dispose() }
    }
}

function Invoke-SelfTest {
    Write-Host "脚本目录 : $script:AppDir"
    Write-Host "清单文件 : $script:ConfigPath"
    $items = @(Get-LinkItems -Path $script:ConfigPath)
    Write-Host ("解析条目 : {0} 个（其中链接 {1} 个）" -f $items.Count, @($items | Where-Object { $_.Kind -eq 'link' }).Count)
    foreach ($i in $items) {
        if ($i.Kind -eq 'link') { Write-Host ("  - {0}  ->  {1}" -f $i.Name, $i.Url) }
        elseif ($i.Kind -eq 'header') { Write-Host ("  [分组] {0}" -f $i.Name) }
    }

    $form = Build-Ui
    Update-Content
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()
    Write-Host ("界面构建 : OK（{0} 个控件）" -f $script:Flow.Controls.Count)
    $form.Hide()

    $hk = Register-HotKey
    Write-Host ("全局热键 : {0}" -f $(if ($hk) { "$script:HotKeyText 注册成功" } else { '注册失败（可能已被其它程序占用），其余功能不受影响' }))
    Unregister-HotKey

    $form.Dispose()
    Write-Host '自检完成。'
}

# 自检用：把浮窗渲染成 PNG，方便确认外观
function Invoke-Capture {
    param([string]$OutPath)

    $form = Build-Ui
    Update-Content
    $form.Show()
    $form.Activate()

    for ($i = 0; $i -lt 12; $i++) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    }

    $bmp = New-Object System.Drawing.Bitmap($form.Width, $form.Height)
    $form.DrawToBitmap($bmp, (New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)))
    $bmp.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()

    $form.Hide()
    $form.Dispose()
    Write-Host "已生成截图：$OutPath"
}

if ($Capture) {
    Invoke-Capture -OutPath $Capture
}
elseif ($Test) {
    Invoke-SelfTest
}
else {
    Start-App
}
