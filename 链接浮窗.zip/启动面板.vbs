Option Explicit
' Start the Link Panel silently (no console window). Keep this file ASCII-only.
Dim fso, shell, appDir, exe, ps1, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

appDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = fso.BuildPath(appDir, "LinkPanel.ps1")
exe = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")

If Not fso.FileExists(ps1) Then
    MsgBox "LinkPanel.ps1 was not found next to this file.", 16, "Link Panel"
    WScript.Quit 1
End If

cmd = """" & exe & """ -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """"
shell.Run cmd, 0, False
